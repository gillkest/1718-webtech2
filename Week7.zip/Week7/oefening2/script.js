/****************************************************
@author: Gilles Kesteleyn
@created:  22/03/2018
@modified: 22/03/2018
@copyright: Artevelde University College Ghent
@function: Plaats hier een korte samenvatting van jouw script
****************************************************/


// functie expressie om JSON-request via url uit te voeren
const getJSON = function(url, callback) {
    var xhr = new XMLHttpRequest();
    xhr.open('GET', url, true);
    xhr.responseType = 'json';
    xhr.onload = function() {
      var status = xhr.status;
      if (status === 200) {
        callback(null, xhr.response);
      } else {
        callback(status, xhr.response);
      }
    };
    xhr.send();
};

// get json data
getJSON('https://evelienrutsaert.github.io/recourses/recipes.json', function(error, data) {
    // show error
    if(error) {  
        // do something here
        return false;
    }

    // loop through all recipes
    for(let i = 0; i < data.length; i++) {

      // current parking object
      let recipe = data[i];

      // do magic here
      document.getElementById("recipes").innerHTML += 
      "<div class='col-4'>" +
       "<div class='card'>" +
           "<img class='card-img-top' src=' " + recipe.image + "' alt='afbeelding recept'>" +
           "<div class='card-block'>" +
                "<h4 class='card-title'> " + recipe.name + "</h4>" +
               "<div class='card-ingredients'>" +
              "Porties: " + recipe.portions + "</br>" + "Ingrediënten: " + recipe.ingredients +
              "</div>" +
               "<div class='card-text'>" +
                   recipe.directions +
               "</div>" +
           "</div>" +
       "</div>" +
   "</div>";

    }
  });
  