/****************************************************
@author: Gilles Kesteleyn
@created:  22/03/2018
@modified: 22/03/2018
@copyright: Artevelde University College Ghent
@function: Plaats hier een korte samenvatting van jouw script
****************************************************/


//KONOP DECLAREREN
const button = document.getElementById('btnMakeJoke');


// functie expressie om JSON-request via url uit te voeren
const getJSON = function(url, callback) {
    var xhr = new XMLHttpRequest();
    xhr.open('GET', url, true);
    xhr.responseType = 'json';
    xhr.onload = function() {
      var status = xhr.status;
      if (status === 200) {
        callback(null, xhr.response);
      } else {
        callback(status, xhr.response);
      }
    };
    xhr.send();
};

button.addEventListener('click', function(){

    //SKILLED
      const firstName = document.getElementById('firstNameField').value;
      const lastName = document.getElementById('lastNameField').value;

    // get json data
      const url = 'http://api.icndb.com/jokes/random?firstName=' + firstName + '&lastName=' + lastName;


      getJSON(url, function(error, data){

        document.getElementById("jokeList").innerHTML += "<li>" + data.value.joke + "</li>";

      });

})