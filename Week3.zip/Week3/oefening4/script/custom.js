/*********************************************************************
* @author     Gilles Kesteleyn
* @created    01/03/2018
* @modified   01/03/2018
* @copyright  Copyright © 2017-2018 Artevelde University College Ghent
* @function   Les 3 oefening 4
*********************************************************************/

function chessboard(){
  
    var drawChess = ' ';

    let i=1
    for (i ; i <= 60; i++) { 
        document.write(schaken(i));
    };
    
    function schaken(i) {
        if ((i % 10 == 0)
                ){
                return "<br>";
                }
        if ((i % 2 == 0)
                ){
                return "#";
                }
        else {
                return '  ';
                }
        }

        return drawChess;
 
}

document.write(chessboard());