/*********************************************************************
* @author     Gilles Kesteleyn
* @created    01/03/2018
* @modified   01/03/2018
* @copyright  Copyright © 2017-2018 Artevelde University College Ghent
* @function   Les 3 oefening 2
*********************************************************************/

let popcorn;
let hamburger, donut, pizza, fries, hotdog;

let popcornString = prompt('Geef de waarde in van een heerlijk emmertje popcorn');
popcorn = parseInt(popcornString);

let hamburgerString = prompt('Geef de waarde in van een heerlijke hamburger');
hamburger = parseInt(hamburgerString);

let donutString = prompt('Geef de waarde in van een heerlijke donut');
donut = parseInt(donutString);

//_____________________________________________________________________________________

let elResult1 = document.getElementById('result1');
elResult1.value = popcorn + popcorn + popcorn;

let elResult2 = document.getElementById('result2');
let result2 = popcorn + hamburger + hamburger;
elResult2.value = result2;

let elResult3 = 
document.getElementById('result3');
let result3 = 2*donut + hamburger + 2*donut;
elResult3.value = result3;

let elResult4 = document.getElementById('result4');
let result4 = hamburger + donut * popcorn;

//_____________________________________________________________________________________

var elButton = document.getElementById('check');
elButton.onclick=function() {
  

  var userValue = parseInt(elResult4.value);
  if(result4 == userValue) 
    {
      alert('Goed gewerkt, je verdient een stuk pizza');
    }
    else 
    {
      alert('Jeetje, je mag nog wat studeren');
    }
}