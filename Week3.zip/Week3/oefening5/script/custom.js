/*********************************************************************
* @author     Gilles Kesteleyn
* @created    01/03/2018
* @modified   01/03/2018
* @copyright  Copyright © 2017-2018 Artevelde University College Ghent
* @function   Les 3 oefening 5
*********************************************************************/



function check(){
    const secretPassword = 'kellypfaff';
let attempt = prompt('Wat is het wachtwoord?');
let i=1;

    while (attempt){
        if(attempt != secretPassword){
        let attempt = prompt('Wat is het wachtwoord?');
        i++;
        }   
        
        else if(attempt == secretPassword) {
            document.write("Welkom, jij weet het wachtwoord en hebt "+ i +" keer proberen raden.");
        }

    




}
}

document.write(check());
