/*********************************************************************
* @author     Gilles Kesteleyn
* @created    01/03/2018
* @modified   01/03/2018
* @copyright  Copyright © 2017-2018 Artevelde University College Ghent
* @function   Les 3 oefening 3
*********************************************************************/
//een landschap schrijven in de console

function landscape(){
  
    var landscapeDrawing = '';
    
    function flatArea(amountFlatAreas){
      
      var flat = '_';
      var longFlat = flat.repeat(amountFlatAreas); 
      landscapeDrawing = landscapeDrawing + longFlat;
    }
    
    function mountainArea(amountTops){
      var startMountain = '/';
      var endMountain = '\\';
      var top = "'";
      var longTop = startMountain + top.repeat(amountTops) + endMountain;
      
      landscapeDrawing = landscapeDrawing + longTop;
      
    }
    flatArea(3);
    mountainArea(6);
    flatArea(9);
    mountainArea(4);
    flatArea(7);
    mountainArea(10);
    flatArea(4);
    
    return landscapeDrawing;
  }

  document.write(landscape());