/*********************************************************************
* @author     Gilles Kesteleyn
* @created    01/03/2018
* @modified   01/03/2018
* @copyright  Copyright © 2017-2018 Artevelde University College Ghent
* @function   Les 3 oefening 1
*********************************************************************/

let i = prompt('Geef de beginwaarde in');
let einde = prompt('Geef de eindwaarde in');

for (i ; i <= einde; i++) { 
    document.write(deelbaar(i) + "<br>");
};

function deelbaar(i) {
  if ((i % 15 == 0)
      ){
      return "bitterbal";
      }
  else if((i % 3 == 0)
   ){
      return "bitter";  
  }
  else if ((i % 5 == 0)
   ){
    return "bal";
  }
  else {
    return i;
  }
  
};