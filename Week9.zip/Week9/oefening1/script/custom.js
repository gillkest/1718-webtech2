
//Declareren
let btnSubmit = document.getElementById("save");
let inputField = document.getElementById("deMol");


//Click event zetten op de knop
btnSubmit.addEventListener('click', function(){
    let mole = inputField.value;
    localStorage.setItem("naam", mole);
})


//localstorage checken
let storedMole = localStorage.getItem("naam");
if(storedMole != null){
    btnSubmit.style.display = "none" ;
    inputField.style.display = "none";
    console.log(storedMole+ " is de mol");
    document.getElementById("test").innerHTML = "<p>" + storedMole + " is de mol" + "</p>";;
}