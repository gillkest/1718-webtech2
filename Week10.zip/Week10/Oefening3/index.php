
<?php
include('header.php');
?>


<!-- Begin page content -->
    <main role="main" class="container">
      <h1 class="mt-5">Home pagina</h1>
      <p class="lead">Pas het project aan zodat we gebruik maken van <code>require</code> in PHP. </p>
      <p>Uiteindelijk hebben we de volgende bestanden <code>index.php</code>, <code>contact.php</code>, <code>header.php</code>, <code>footer.php</code>.</p>
    </main>

    <?php
include('footer.php');
?>