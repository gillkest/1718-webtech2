 
 <?php
include('header.php');
?>


 <!-- Begin page content -->
 <main role="main" class="container">
      <h1 class="mt-5">Contact pagina</h1>
      <p class="lead">Hier komt mijn contact-informatie + formulier</p>
    </main>

<?php
include('footer.php');
?>