<?php

$space = 'universe';
echo $space;
?>