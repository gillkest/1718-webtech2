<?php

//dit is single line comment
#single line comment option 2
/**  multi line comment
* hoera
*
*
*
*/

include ("content.php");

echo"hello voorbeeld 1";
echo '<br>';

$i = 2;
$j = 4.56;
$k = $i + $j;

echo $k;
echo '<br';


echo $space;

?>