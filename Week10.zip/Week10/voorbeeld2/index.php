<?php

$myFavoriteNumber = 92;
$myFavoriteFloat = 3.1415;
$myFavoriteBoolean = true;
$myFavoriteString = "Uw Naam is ";
$myFavoriteArray = ["gilles","kesteleyn","test"];

var_dump($myFavoriteNumber);
var_dump($myFavoriteFloat);
var_dump($myFavoriteBoolean);
var_dump($myFavoriteString);
var_dump($myFavoriteArray);


?>