<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Week 10 oefening 2</title>
    
</head>
<body>

        <?php 
        
        $snelDier = "Eddy";
        $soortSnelDier = "Tijger";
        $traagDier = "oscar";
        $soortTraagDier = "schildpad";

        
        ?>
    
        
        <h1>De <?php echo $soortSnelDier ?> en de <?php echo $soortTraagDier ?> </h1>
        <p>
        <?= $snelDier ?>, De  <?= $soortSnelDier ?> moest altijd lachen wanneer hij  <?= $traagDier ?>, de  <?= $soortTraagDier ?> zag lopen, want het ging zo langzaam. "Ik begrijp niet waarom jij nooit naar iets onderweg gaat," zij hij pesterig. "Als jij eindelijk aankomt, is het altijd te laat en alles is al lang voorbij."
        
        De <?= $soortTraagDier ?> lachte een beetje. "Vlug ben ik niet," zei hij, "maar toch durf ik te wedden, dat ik eerder aan de overkant van dit veld ben dan jij. Zullen we een wedstrijd houden? Dan kun je het zien."
        
        "Goed!" riep  <?= $snelDier ?> en meteen sprong hij er vandoor, zo snel als hij kon. <?= $soortTraagDier ?>, de <?= $soortTraagDier ?> ging heel rustig op weg.
        
        Nu was het die dag erg warm weer met een brandende zon, en de <?= $soortSnelDier ?> werd halverwege moe en slaperig. "Weet je wat," dacht hij. "Ik doe even een tukje onder die heg hier. Zelfs als die <?= $soortTraagDier ?> me onderwijl voorbij loopt, heb ik hem in een flits weer ingehaald." De  <?= $soortSnelDier ?> ging in de schaduw liggen en sliep in.
        
        <?= $traagDier ?> kroop gestaag voort onder de warme zon.
        
        Pas na lange tijd werd de <?= $soortSnelDier ?> wakker. Het was veel later dan hij dacht en hij keek eens rond. Geen  <?= $soortTraagDier ?> te bekennen. "Nou nou," mompelde hij, "waar zit dat vriendje? Wacht maar, ik zal hem eens wat laten zien."
        
        Als een pijl uit een boog schoot hij weg, door het korte gras, door het koren, over sloten, langs braamstruiken, en bij de laatste bocht bleef hij even staan om te zien waar de eindstreep lag. Daar! En nog geen halve meter ervoor kroop <?= $traagDier ?>, de <?= $soortTraagDier ?>, langzaam maar zeker, stap voor stap, dichter en dichter naar het eindpunt.
        
        Met een geweldige sprong stoof de  <?= $soortSnelDier ?> erop af. Maar hij was te laat. Toen hij de lijn passeerde, was de  <?= $soortTraagDier ?> hem juist voor geweest.
        
        "Zie je nou wel," zei de  <?= $soortTraagDier ?>.
        
        Maar de <?= $soortSnelDier ?> had geen adem meer om te kunnen antwoorden.
    </p>

</body>
</html>