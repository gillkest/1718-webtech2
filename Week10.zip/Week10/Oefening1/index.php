
OEFENING 1

<?php

$a = "mijn naam ";
$b = "is ";
$c = "Gilles";

var_dump($a, $b, $c);
echo"<br>";

echo $a.$b.$c;

?>
