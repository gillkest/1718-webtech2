/****************************************************
@author: Gilles Kesteleyn
@created:  08/03/2018
@modified: 08/03/2018
@copyright: Artevelde University College Ghent
@function: Plaats hier een korte samenvatting van jouw script
****************************************************/

//Alle elementen met deze tag ophalen (arrays)
let anchorTags = document.getElementsByTagName('a');
let strongTags = document.getElementsByTagName('strong');
let spanTags = document.getElementsByTagName('span');

//eerste uit array halen: de link
let linkElement = anchorTags[0];

//event toepassen
linkElement.addEventListener('mouseover', function(){
    let firstStrongTag = strongTags[0];
    firstStrongTag.style.color = 'orange';

    strongTags[1].style.color = "orange";

    for(let i=1; i < spanTags.length; i++ ){
        spanTags[i].style.color = 'purple';
    }

    //linkElement.style.backgroundcolor = 'pink'; ???

});

//event terugzetten
linkElement.addEventListener('mouseout', function(){
    let firstStrongTag = strongTags[0];
    firstStrongTag.style.color = 'black';

    strongTags[1].style.color = "black";

    for(let i=1; i < spanTags.length; i++ ){
        spanTags[i].style.color = 'black';
    }


});