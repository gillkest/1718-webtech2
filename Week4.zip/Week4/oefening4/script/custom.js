/****************************************************
@author: Gilles Kesteleyn
@created:  08/03/2018
@modified: 08/03/2018
@copyright: Artevelde University College Ghent
@function: Plaats hier een korte samenvatting van jouw script
****************************************************/
