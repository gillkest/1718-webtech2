/****************************************************
@author: Gilles Kesteleyn
@created:  08/03/2018
@modified: 08/03/2018
@copyright: Artevelde University College Ghent
@function: Plaats hier een korte samenvatting van jouw script
****************************************************/



function createBrick(color) {

    //div el aanmaken
    let brick = document.createElement('div');

    //klasse toevoegen
    brick.className = 'brick brick-' + color;

    return brick;
}



function addBrickToWall(color, wallNumber) {

    let wallId = 'wall-' + wallNumber;
    let wall = document.getElementById(wallId);

    //steen juiste kleur meegeven
    let newBrick = createBrick(color);

    //steen toevoegen aan muur
    wall.appendChild(newBrick);
}



function removeBrickFromWall(color, wallNumber){

    let wallId = 'wall-' + wallNumber;
    let wall = document.getElementById(wallId);

    //de klasse van de brick
    let brickClass = "brick brick-" + color;

    //de bricks in een var steken
    let bricks = document.getElementsByClassName(brickClass);

    //aantal stenen tellen
    let amountBricks = bricks.length;

    if(amountBricks > 0){
      wall.removeChild(bricks[0]);
    } 
    else alert('Er zijn geen stenen meer beschikbaar om te verwijderen.');
    
  }




  function getAmountBricks(color){
    let brickClass = "brick brick-" +color;
    let bricks = document.getElementsByClassName(brickClass);
    let amountBricks = bricks.length;
    
    return amountBricks;
  }
