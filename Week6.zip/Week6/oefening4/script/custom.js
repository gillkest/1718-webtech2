/****************************************************
@author: Gilles Kesteleyn
@created:  22/03/2018
@modified: 22/03/2018
@copyright: Artevelde University College Ghent
@function: Plaats hier een korte samenvatting van jouw script
****************************************************/
