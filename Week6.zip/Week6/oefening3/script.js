 /****************************************************
@author: Gilles Kesteleyn
@created:  22/03/2018
@modified: 22/03/2018
@copyright: Artevelde University College Ghent
@function: Plaats hier een korte samenvatting van jouw script
****************************************************/
 
  
  
  const getJSON = function(url, callback) {
    var xhr = new XMLHttpRequest();
    xhr.open('GET', url, true);
    xhr.responseType = 'json';
    xhr.onload = function() {
      var status = xhr.status;
      if (status === 200) {
        callback(null, xhr.response);
      } else {
        callback(status, xhr.response);
      }
    };
    xhr.send();
};


getJSON('https://www.booknomads.com/api/v0/isbn/9789000035526', function(error, data) {
    // show error
    if(error) {  
        // do something here
        return false;
    }

    // loop through all recipes
    for(let i = 0; i < data.length; i++) {

      // current parking object
      let bookNumber = document.getElementById("isbnSearchInput").value;

      // do magic here
      document.getElementById("bookIsbn").innerHTML += 
      
      bookNumber.ISBN



      ;

    }
  });
  