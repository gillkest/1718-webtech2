/****************************************************
@author: Gilles Kesteleyn
@created:  15/03/2018
@modified: 15/03/2018
@copyright: Artevelde University College Ghent
@function: Plaats hier een korte samenvatting van jouw script
****************************************************/

//klasse aanmaken voor de honden
function Dog(breed, name, color, age, gender){
    this.breed = breed;
    this.name = name;
    this.color = color;
    this.age = age;
    this.gender = gender;
    // Deel D
    this.birthYear = function(){
      var dateObject = new Date();
      var currentYear = dateObject.getFullYear();
      return currentYear - this.age;
    };
}


//hond aanmaken en in klasse plaatsen met juiste eigenschappen
  var myDog = new Dog("Bearded collie", "samson", "black", 5, "male");

  // Deel A
  console.log(myDog.name);

  // Deel B

  // Deel C
  console.log(myDog.name + " is a " + myDog.gender + " " + myDog.breed +  " with the colors " + myDog.color + " and is " + myDog.age + " years old.");

  // Deel D
  //zie lijn 16
  console.log(myDog.birthYear());

  // Deel E
  myDog.bestToyEver = "rode bal";
  
  console.log(myDog.bestToyEver);

  // Deel F 
  myDog.name = "Bobientje";

  // Deel G