/****************************************************
@author: Gilles Kesteleyn
@created:  15/03/2018
@modified: 15/03/2018
@copyright: Artevelde University College Ghent
@function: Plaats hier een korte samenvatting van jouw script
****************************************************/

let books = [
    {title: 'Harry Potter',
    author: 'J.K. Rowling',
    alreadyRead: false
    },

    {title: 'Jane Eyre',
    author: 'Charlotte Brontë',
    alreadyRead: true
    },

    {title: 'De verschrikkelijke schoolmeester.',
    author: 'Dolf Verroen',
    alreadyRead: true
    }
];

let divBook = document.getElementById('book');

for(let i=0; i<books.length; i++) {

        //divBook.innerHTML += '<h2>' + books[i].title + '</h2>';
        //divBook.innerHTML +=  '<h4>' + books[i].author + '</h4>' ;

        if (books[i].alreadyRead == true){
            divBook.innerHTML += '<h3>' + "Je las reeds het boek " + books[i].title + " by " + books[i].author + '</h3>';
        }else{
            divBook.innerHTML += '<h3>' + "Je moet het boek " + books[i].title + " by " + books[i].author + " nog steeds lezen."+ '</h3>';}

        divBook.innerHTML += '</br>';
}



//betere methode via console.log gemaakt
let book = function(name, writer, alreadyRead){
    this.title = name,
    this.author = writer,
    this.alreadyRead = alreadyRead,
    this.output = function() {
        if(this.alreadyRead){
            return "al gelezen";
        }
        else {
            return "nog niet gelezen";
        }
    }
}
 let myBook = new book('twilight', 'stef meyer', false);

 console.log(myBook.output());