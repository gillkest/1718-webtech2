/****************************************************
@author: Gilles Kesteleyn
@created:  15/03/2018
@modified: 15/03/2018
@copyright: Artevelde University College Ghent
@function: Plaats hier een korte samenvatting van jouw script
****************************************************/

/** 
function recept(naam, porties, ingredienten) {
    this.naam = soep;
    this.porties = 4;
    this.ingredienten = ["pompoen", "wortel", "water", "bouillon"];

	this.hetRecept = function () {
        return this.naam;
        return this.porties;
        return this.ingredienten;
		};
}
*/


let recipe= {
    name: "Pizza Margharita",
    servings: 2,
    difficulty: "easy",
    ingredients: [
        'cheese',
        'dough',
        'tomato sauce',
        'basil',
        'garlic'
    ]
};

//console.log(recipe.name);

let divRecipe = document.getElementById('recipe');

//naam printen
divRecipe.innerHTML = '<h2>' + recipe.name + '</h2>';

//servings printen
divRecipe.innerHTML += '<h3>' + "Servings = " + recipe.servings + '</h3>';

//list aanmaken
divRecipe.innerHTML += '<ul>';

//array doorlopen en in een li steken
for(let i=0; i<recipe.ingredients.length; i++) {
    divRecipe.innerHTML += "<li>" +recipe.ingredients[i] + "</li>"
}

//list sluiten
divRecipe.innerHTML += '</ul>';