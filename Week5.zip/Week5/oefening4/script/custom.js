/****************************************************
@author: Gilles Kesteleyn
@created:  15/03/2018
@modified: 15/03/2018
@copyright: Artevelde University College Ghent
@function: Plaats hier een korte samenvatting van jouw script
****************************************************/
